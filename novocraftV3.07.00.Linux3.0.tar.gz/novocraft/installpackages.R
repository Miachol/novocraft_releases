#!/usr/bin/Rscript --no-save --no-restore  
install.packages(c("getopt","gridExtra","reshape","ggplot2","plyr"), repos="http://cran.r-project.org")

